//
//  ScriptApp.swift
//  Script
//
//  Created by Alessandro Ricci on 16/02/24.
//

import SwiftUI

@main
struct ScriptApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
